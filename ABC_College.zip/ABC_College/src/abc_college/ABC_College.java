/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package abc_college;

import java.util.Scanner;

//This class represents the main application for managing students at ABC College
//It provides a menu-driven interface for capturing, searching, deleting, and reporting on students

/**
 *
 * @author ishka
 */

public class ABC_College {
     public final static Scanner kb = new Scanner(System.in);
    
    /*
    The main method of the application
    It initializes the application and launches the menu
    */
    
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        ABC_College method = new ABC_College();
        System.out.println("STUDENT MANAGEMENT APPLICATION\n"
                + "****************************************\n"
                + "Enter (1) to launch menu or any other key to exit");
        method.menuLaunch(kb);
    }
    /*
    Launches the initial menu of the application.
    This method reads user input to determine whether to proceed to the main menu or exit.
    */
    
    public void menuLaunch(Scanner kb) {
        int onlyOne = 1;    //Used to enforce entering only 1 for menu launch
        int menuStart;
        
      //  Scanner kb = new Scanner (System.in);
        Student student = new Student();
        ABC_College method = new ABC_College();
        
        if (kb.hasNextInt()) {
            menuStart = kb.nextInt();
            switch (menuStart) {
                case 1: menuItems(kb); break; //Proceed to the main menu
                default: student.ExitStudentApplication(kb); break; //Exit the application
            }
        } else {
            student.ExitStudentApplication(kb);   //Exit the application if non-integer input is detected
        }
        
    }
    
    /*
    Displays and handles the main menu items of the application.
    Allows users to choose from various student management actions.
    */
    public void menuItems(Scanner kb) {
        int menuChoice;
        boolean notRegistered = false;
        
  //      Scanner kb = new Scanner (System.in);
        Student student = new Student();
        
        while(!notRegistered) {
        System.out.println("Please select one of the following menu items: \n"
                        + "(1) Capture a new Student.\n"
                        + "(2) Search for a student.\n"
                        + "(3) Delete a student.\n"
                        + "(4) Print student report.\n"
                        + "(5) Exit Application.");
        
        menuChoice = kb.nextInt();
        
        //Takes user to the method of chosen purpose
        switch(menuChoice) {
            case 1: student.SaveStudent(); notRegistered = true; break; 
            case 2: student.SearchStudent(menuChoice); notRegistered = true; break;
            case 3: student.DeleteStudent(kb); notRegistered = true; break;
            case 4: student.StudentReport(kb); notRegistered = true; break;
            case 5: student.ExitStudentApplication(kb); notRegistered = true; break;
            default: System.out.println("Please enter a valid option!!!"); break;
        }
      } 
    }
    
}
