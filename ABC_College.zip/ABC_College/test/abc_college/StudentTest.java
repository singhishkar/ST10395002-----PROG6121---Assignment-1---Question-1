/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package abc_college;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.InputMismatchException;
import java.util.Scanner;

import static org.junit.Assert.*;

/**
 *
 * @author ishka
 */
public class StudentTest {
    private Student student;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    
    @Before
    public void setUp() {
        student = new Student();
    }

    @After
    public void restoreStreams() {
        System.setOut(originalOut);
    }
    
    @Test
    public void TestSaveStudent() {
        int testId = 123;
        String testName = "John Doe";
        int testAge = 18;
        String testEmail = "johndoe@example.com";
        String testCourse = "Computer Science";

       // Student.kb = new Scanner("123\nJohn Doe\n18\njohndoe@example.com\nComputer Science\n");
       
       Student mo = new Student();
       Student.ID.add(123);
       Student.age.add(18);
       Student.course.add("Computer Science");
       Student.email.add("johndoe@example.com");
       Student.name.add( "John Doe");
        //Check if the student details are saved correctly
        assertEquals(1, Student.ID.size());
        assertEquals(1, Student.name.size());
        assertEquals(1, Student.age.size());
        assertEquals(1, Student.email.size());
        assertEquals(1, Student.course.size());

        assertEquals(testName, Student.name.get(0));
        assertEquals(testEmail, Student.email.get(0));
        assertEquals(testCourse, Student.course.get(0));
    }
    
    @Test
    public void TestSearchStudent() {
//        //Set up test data by adding a student to the database
//        int testId = 1;
//        String testName = "John";
//        int testAge = 20;
//        String testEmail = "john@example.com";
//        String testCourse = "Computer Science";
//        Student.ID.add(testId);
//        Student.name.add(testName);
//        Student.age.add(testAge);
//        Student.email.add(testEmail);
//        Student.course.add(testCourse);
//
//        //Call the SearchStudent() method with the test student ID
//       // student.SearchStudent(testId); // Provide the testId as an argument
//
//        //Capture the output
//        String result = outContent.toString();
//
//        //Define the expected output
//        String expectedOutput = "STUDENT ID: " + testId + "\n"
//                + "STUDENT NAME: " + testName + "\n"
//                + "STUDENT AGE: " + testAge + "\n"
//                + "STUDENT EMAIL: " + testEmail + "\n"
//                + "STUDENT COURSE: " + testCourse + "\n"
//                + "----------------------------------------\n"
//                + "Enter (1) to launch menu or any other key to exit\n";
//
//        //Assert that the actual result matches the expected output
//        assertEquals(expectedOutput, result);


//we are going to preoare our test data '
Student stu = new Student ();

stu.ID.add(321);
stu.name.add("Reginal");
stu.age.add(16);
stu.email.add("reginal@gmail.com");
stu.course.add("BCAD");

//Scanner scanner = new Scanner ("321\n\n");

String found= stu. SearchStudent(321);
assertNotNull(found);


    }

    @Test
    public void TestSearchStudent_StudentNotFound() {
        //Create an instance of the Student class
        Student student = new Student();
        
        //Clear the student lists
        Student.ID.clear();
        Student.name.clear();
        Student.age.clear();
        Student.email.clear();
        Student.course.clear();
        
        //Set up a scanner to provide input
        //student.kb = new Scanner("123\n");
        
        // Redirect System.out to capture the output
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        
        // Call the SearchStudent method
        student.SearchStudent(0);
        
        // Check if the output contains the expected message
        String expectedOutput = "Student with student ID: 123 was not found!";
        assertTrue(outContent.toString().contains(expectedOutput));
        
        // Restore System.out to its original state
        System.setOut(System.out);
    }

    @Test
    public void TestDeleteStudent() {
        //Add a student to the database
        Student.ID.add(1); 
        Student.name.add("John"); 
        Student.age.add(20);
        Student.email.add("john@example.com"); 
        Student.course.add("Math");

        // Call the DeleteStudent method with the student's ID
        Scanner scanner = new Scanner("123");
        student.DeleteStudent(scanner);

        // Assert that the student has been successfully deleted
        assertFalse(Student.ID.contains(1));
        assertFalse(Student.name.contains("John"));
        assertFalse(Student.age.contains(20));
        assertFalse(Student.email.contains("john@example.com"));
        assertFalse(Student.course.contains("Math"));
    }

    @Test
    public void TestDeleteStudent_StudentNotFound() {
        //Create an instance of the Student class
        Student student = new Student();

        //Set up some sample data in the student's ID list
        Student.ID.add(1);
        Student.ID.add(2);
        Student.ID.add(3);

        //Redirect System.out to capture the output
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        //Attempt to delete a student with an ID that doesn't exist
        Scanner scanner = new Scanner("123");
        student.DeleteStudent(scanner);

        //Restore the original System.out
        System.setOut(System.out);

        //Check if the captured output message matches the expected message
        String expectedMessage = "Student with ID 0 not found.";
        assertEquals(expectedMessage, outContent.toString().trim());
    }
    
    @Test
    public void TestStudentAge_StudentAgeValid() {
        //Add a sample student to the database
        Student.ID.add(1);
        Student.name.add("John");
        Student.age.add(20); // Valid age
        Student.email.add("john@example.com");
        Student.course.add("Computer Science");

        //Redirect standard input to a ByteArrayInputStream for testing
        String input = "1\n"; // Simulate user entering '1' to search
        System.setIn(new java.io.ByteArrayInputStream(input.getBytes()));

        //Capture the output for testing
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        //Call the SearchStudent method
        student.SearchStudent(0);

        //Assert that the output contains the student information
        String expectedOutput = "STUDENT ID: 1\n" +
                "STUDENT NAME: John\n" +
                "STUDENT AGE: 20\n" +
                "STUDENT EMAIL: john@example.com\n" +
                "STUDENT COURSE: Computer Science\n";
        assertEquals(expectedOutput, outputStream.toString());

        //Reset standard input and output streams
        System.setIn(System.in);
        System.setOut(System.out);
    }
    
    @Test
    public void TestStudentAge_StudentAgeInvalid() {
        //Add a student with an age less than 16
        Student.ID.add(1);
        Student.name.add("John");
        Student.age.add(15); // Invalid age, less than 16
        Student.email.add("john@example.com");
        Student.course.add("Computer Science");

        //Capture the output of the method using a ByteArrayOutputStream
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        //Call the SearchStudent method with the invalid age
        student.SearchStudent(0);

        //Check if the output contains the error message
        String expectedOutput = "Student with student ID: 1 was not found!\n";
        assertTrue(outContent.toString().contains(expectedOutput));
    }
    
    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        //Test with an invalid character in student age
        student.age.clear(); // Clear the age list to ensure it's empty
        student.age.add(25); // Add a valid age to the list
        student.age.add(20); // Add another valid age to the list
        student.age.add(21); // Add another valid age to the list
        
        //Now, let's add an age with an invalid character
        student.age.add(Integer.parseInt("abc"));
        
        //Use try-catch to catch the InputMismatchException
        try {
            student.SearchStudent(0);
            fail("Expected InputMismatchException");
        } catch (InputMismatchException e) {
            // Test passed if InputMismatchException is thrown
            assertEquals("InputMismatchException", e.getClass().getSimpleName());
        }
    }
    
    @Test
    public void testSearcch(){
        //we are going to preoare our test data '
Student stu = new Student ();

stu.ID.add(321);
stu.name.add("Reginal");
stu.age.add(16);
stu.email.add("reginal@gmail.com");
stu.course.add("BCAD");

//Scanner scanner = new Scanner ("321\n\n");

String found= stu. SearchStudent(321);
assertNotNull(found);


    }
}
